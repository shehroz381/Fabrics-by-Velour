package com.example.smesterproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
