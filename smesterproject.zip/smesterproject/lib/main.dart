import 'package:flutter/material.dart';

void main() {
  runApp(VelourApp());
}

class VelourApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}
// ------------------ GLOBALS ------------------
String savedUsername = "";
String savedPassword = "";
Color golden = Color(0xFFD4AF37);

Map<String, Map<String, int>> stockData = {
  "Pre-Winter Khaddar": {
    "Cream White": 5,
    "Light Gray": 3,
    "Cacti Green": 7,
    "Light Green": 4,
    "Camel Brown": 6,
    "Charcoal": 2,
  },
  "Prestige Khaddar": {
    "Jet Black": 5,
    "Olive": 3,
    "Charcoal": 4,
    "Hazel Brown": 6,
    "Caramel Brown": 7,
    "Graig": 2,
  },
  "Egyptian Cotton": {
    "Off-White": 3,
    "Jet-Black": 2,
    "Cream": 5,
    "Navy Blue": 4,
    "Jade-Blue": 6,
    "Pre-White": 3,
  },
};

Map<String, int> priceData = {
  "Pre-Winter Khaddar": 2500,
  "Prestige Khaddar": 3200,
  "Egyptian Cotton": 4000,
};

final List<Map<String, dynamic>> categories = [
  {
    "name": "Pre-Winter Khaddar",
    "image": "assets/p1.jpg",
    "clothes": [
      {"name": "Cream White", "image": "assets/p1.1.jpg"},
      {"name": "Light Gray", "image": "assets/p1.2.jpg"},
      {"name": "Cacti Green", "image": "assets/p1.3.jpg"},
      {"name": "Light Green", "image": "assets/p1.4.jpg"},
      {"name": "Camel Brown", "image": "assets/p1.5.jpg"},
      {"name": "Charcoal", "image": "assets/p1.6.jpg"},
    ],
  },
  {
    "name": "Prestige Khaddar",
    "image": "assets/p2.jpg",
    "clothes": [
      {"name": "Jet Black", "image": "assets/p2.1.jpg"},
      {"name": "Olive", "image": "assets/p2.2.jpg"},
      {"name": "Charcoal", "image": "assets/p2.3.jpg"},
      {"name": "Hazel Brown", "image": "assets/p2.4.jpg"},
      {"name": "Caramel Brown", "image": "assets/p2.5.jpg"},
      {"name": "Graig", "image": "assets/p2.6.jpg"},
    ],
  },
  {
    "name": "Egyptian Cotton",
    "image": "assets/p3.jpg",
    "clothes": [
      {"name": "Off-White", "image": "assets/p3.1.jpg"},
      {"name": "Jet-Black", "image": "assets/p3.2.jpg"},
      {"name": "Cream", "image": "assets/p3.3.jpg"},
      {"name": "Navy Blue", "image": "assets/p3.4.jpg"},
      {"name": "Jade-Blue", "image": "assets/p3.5.jpg"},
      {"name": "Pre-White", "image": "assets/p3.6.jpg"},
    ],
  },
];

// ------------------ LOGIN PAGE ------------------
class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController user = TextEditingController();
  TextEditingController pass = TextEditingController();
  String msg = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            child: Image.asset("assets/bg.jpg", fit: BoxFit.cover),
          ),
          Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(30),
              child: Column(
                children: [
                  Text("Fabrics by Velour",
                      style: TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.bold,
                          color: golden)),
                  SizedBox(height: 40),
                  TextField(
                    controller: user,
                    decoration: InputDecoration(
                        labelText: "Username",
                        filled: true,
                        fillColor: Colors.white),
                  ),
                  TextField(
                    controller: pass,
                    decoration: InputDecoration(
                        labelText: "Password",
                        filled: true,
                        fillColor: Colors.white),
                    obscureText: true,
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (user.text == savedUsername &&
                          pass.text == savedPassword &&
                          savedUsername.isNotEmpty) {
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) => HomePage()));
                      } else {
                        setState(() {
                          msg = "Invalid Login ❌";
                        });
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(150, 50),
                      backgroundColor: golden,
                    ),
                    child: Text("Login",
                        style: TextStyle(color: Colors.white, fontSize: 18)),
                  ),
                  SizedBox(height: 10),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SignUpPage()));
                      },
                      child: Text("Don't have account? Sign Up")),
                  SizedBox(height: 10),
                  Text(msg, style: TextStyle(color: Colors.black)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ------------------ SIGN UP PAGE ------------------
class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  TextEditingController newUser = TextEditingController();
  TextEditingController newPass = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(30),
          child: Column(
            children: [
              Text("Create Account",
                  style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.black)),
              SizedBox(height: 40),
              TextField(
                controller: newUser,
                decoration: InputDecoration(labelText: "New Username"),
              ),
              TextField(
                controller: newPass,
                decoration: InputDecoration(labelText: "New Password"),
                obscureText: true,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  savedUsername = newUser.text;
                  savedPassword = newPass.text;
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(150, 50),
                  backgroundColor: golden,
                ),
                child: Text("Sign Up",
                    style: TextStyle(color: Colors.white, fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ------------------ HOME PAGE ------------------
class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: golden, title: Text("Fabrics By Velour")),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.white),
              child: Center(
                child:
                SizedBox(height: 110, child: Image.asset("assets/logo.jpg")),
              ),
            ),
            ListTile(title: Text("Home"), onTap: () => Navigator.pop(context)),
            ListTile(
              title: Text("Categories"),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => CategoriesPage()));
              },
            ),
            ListTile(
              title: Text("Inventory"),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => InventoryPage()));
              },
            ),
            ListTile(
              title: Text("About Us"),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => AboutUsPage()));
              },
            ),
            ListTile(
              title: Text("Logout"),
              onTap: () {
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => LoginPage()));
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(25),
        child: Column(
          children: [
            SizedBox(height: 20),
            SizedBox(height: 140, child: Image.asset("assets/logo.jpg")),
            SizedBox(height: 25),
            Text(
              "Welcome to Velour Fabrics",
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 32, fontWeight: FontWeight.bold, color: golden),
            ),
            SizedBox(height: 25),
            Text(
              "Velour is built on the beauty of fine textiles. We honor the art of fabric-making by curating exceptional materials that reflect timeless quality, heritage techniques, and refined texture.",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, height: 1.5, color: Colors.black87),
            ),
          ],
        ),
      ),
    );
  }
}

// ------------------ ABOUT US PAGE ------------------
class AboutUsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: golden, title: Text("About Us")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Text(
          "Velour Fabrics — A brand of premium textiles.\nWe provide high-quality fabric collections with a focus on luxury and comfort.",
          style: TextStyle(fontSize: 18, height: 1.5),
        ),
      ),
    );
  }
}

// ------------------ CATEGORIES PAGE ------------------
class CategoriesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Categories"), backgroundColor: golden),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: GridView.builder(
          itemCount: categories.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 1,
            mainAxisExtent: 180,
            crossAxisSpacing: 10,
            mainAxisSpacing: 15,
          ),
          itemBuilder: (context, index) {
            final category = categories[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CategoryDetailPage(
                      categoryName: category["name"],
                      clothes: category["clothes"],
                    ),
                  ),
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  image: DecorationImage(
                    image: AssetImage(category["image"]),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.black38,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Text(
                    category["name"],
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ------------------ CATEGORY DETAIL PAGE ------------------
class CategoryDetailPage extends StatelessWidget {
  final String categoryName;
  final List<Map<String, String>> clothes;

  CategoryDetailPage({required this.categoryName, required this.clothes});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(categoryName), backgroundColor: golden),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: GridView.builder(
          itemCount: clothes.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 15,
            crossAxisSpacing: 15,
            mainAxisExtent: 200,
          ),
          itemBuilder: (context, index) {
            var cloth = clothes[index];
            var clothName = cloth["name"]!;
            int stock = stockData[categoryName]![clothName]!;
            int price = priceData[categoryName]!;

            return Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: DecorationImage(
                  image: AssetImage(cloth["image"]!),
                  fit: BoxFit.cover,
                ),
              ),
              child: Container(
                alignment: Alignment.bottomCenter,
                decoration: BoxDecoration(
                  color: Colors.black38,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: EdgeInsets.all(8),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        clothName,
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 5),
                      Text(
                        "Stock: $stock | Price: $price PKR",
                        style: TextStyle(
                            color: Colors.white70,
                            fontWeight: FontWeight.bold,
                            fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ------------------ INVENTORY PAGE ------------------
class InventoryPage extends StatefulWidget {
  @override
  _InventoryPageState createState() => _InventoryPageState();
}

class _InventoryPageState extends State<InventoryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Inventory"), backgroundColor: golden),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: ListView(
          children: categories.map((category) {
            String categoryName = category["name"];
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 10),
                Text(categoryName,
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: golden)),
                SizedBox(height: 5),
                ...stockData[categoryName]!.keys.map((itemName) {
                  int stock = stockData[categoryName]![itemName]!;
                  int price = priceData[categoryName]!;

                  return Card(
                    elevation: 3,
                    child: ListTile(
                      title: Text(itemName),
                      subtitle: Text("Stock: $stock | Price: $price PKR"),
                      trailing: IconButton(
                        icon: Icon(Icons.add, color: golden),
                        onPressed: () {
                          setState(() {
                            stockData[categoryName]![itemName] = stock + 1;
                          });
                        },
                      ),
                    ),
                  );
                }).toList(),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}
